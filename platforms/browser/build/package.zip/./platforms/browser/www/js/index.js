var NAV_HEIGHT = 65;


$(".menuPageLi").click(function () {

    $(this).animate({
        opacity: 0.7
    }, 200, function () {
        $(this).animate({
            opacity: 1
        }, 200)
    })

});


var isMenuPageShown = 1;
$("#nav_menu").click(function () {
    if (isMenuPageShown) {
        $("#menuPage").fadeOut();
        isMenuPageShown = 0;
    } else {
        $("#menuPage").fadeIn();
        isMenuPageShown = 1;
    }
});

$("#nav_reload").click(function () {
    reloadCurrentPage()
});

$("#nav_back").click(function () {
    pageHistory("back");
});

$("#nav_forward").click(function () {
    pageHistory("forward");
});


var history = ["http://wiki.kspu.kr.ua/index.php/%D0%90%D1%83%D0%B4%D0%B8%D1%82%D0%BE%D1%80%D1%96%D1%83%D0%BC"];
function pageHistory(direction) {

    if (direction == "back") {
        console.log("-=-=-=-=-=-=-=- pageHistory + " + direction + "  and size = " + history.length + "-=-=-=-=-=-=-=-");
        if (history.length != 1) {
            var lastLink = history.pop();
            $("#innerBrowser").attr('src', lastLink);
            reloadCurrentPage();
        }
    }
}

$("#homePageLoadButton").click(function () {

    function showHomePage() {

        clearPage();

        $("#menuPage").fadeOut();
        console.log(' $("#menuPage").fadeOut(); ');
    }

    showHomePage();
});


function clearPage() {

    var contentHtml = $("#innerBrowser").contents().find("div#content").html();
    $("#innerBrowser").contents().find("body").css({
        padding: '10px',
        //overflow: 'scroll'
    });
    $("#innerBrowser").contents().find("body").html(contentHtml);

    console.log("-=-=-=-=-=-=-=-=-=-=-=-=- clearPage -=-=-=-=-=-=-=-=-=-=-=-=-=-")
}


$("#browser").load(function () {
    console.log("iframe loaded successfully");
});

function iframeLoaded2() {
    $("#homePageLoadButton").html("Home Page");
    clearPage();
    console.log("-=-=-=-=-=-=-=- IFRAME LOADED -=-=-=-=-=-=-=-");
}

function launch() {

    function setTwoMainDivsHeight() {
        var contentHeight = $("body").height() - NAV_HEIGHT;
        $("#navigation").css({
            height: NAV_HEIGHT + 'px'
        });
        $(".contentDiv").css({
            height: contentHeight + 'px'
        });
    }

    setTwoMainDivsHeight();
}

function reloadCurrentPage() {

    $("#innerBrowser").attr('src', function (i, val) {
        return val;
    });

}

function deviceIsOffline() {
    console.log("-=-=-=-=-=-=-=- deviceIsOffline -=-=-=-=-=-=-=-");
    reloadCurrentPage();
    $("#badInternet").fadeIn();
}

function deviceIsOnline() {
    $("#badInternet").fadeOut();
    console.log("-=-=-=-=-=-=-=- deviceIsOnline -=-=-=-=-=-=-=-");
}


var app = {
    // Application Constructor
    initialize: function () {

        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
        document.addEventListener("online", this.onOnline.bind(this), false);
        document.addEventListener("offline", this.onOffline.bind(this), false);
        document.addEventListener("menubutton", this.onMenuKeyDown.bind(this), false);

        deviceIsOnline();
        launch();
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function () {

    },
    onOffline: function () {
        deviceIsOffline();
    },

    onOnline: function () {
        deviceIsOnline();
    },

    onMenuKeyDown: function () {
        $("#badInternet").fadeIn();
        console.log("\n\n\n\n\n onMenuKeyDown \n\n\n")
    }

};

app.initialize();


